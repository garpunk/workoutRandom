// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCh4pEMOMAN2_Q1FwGyrwhlgEited_QDTA",
  authDomain: "workoutgenerator-18f60.firebaseapp.com",
  projectId: "workoutgenerator-18f60",
  storageBucket: "workoutgenerator-18f60.firebasestorage.app",
  messagingSenderId: "322387921998",
  appId: "1:322387921998:web:6ea3ac5e3aed588905471f",
  measurementId: "G-61BBC53PRE"
};
  